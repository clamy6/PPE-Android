package com.example.arbitre.classe_metier;

import com.example.arbitre.MainActivity;

import java.util.ArrayList;

/**
 * Created by Charline on 04/12/13.
 */
public class Match {

    private int id;
    private int butA;
    private int butB;
    private Club c1;
    private Club c2;

    public Match(){}

    public Match(int id,Club unClub,Club unAutreClub){
        this.id = id;
        this.butA = 0;
        this.butB = 0;
        this.c1 = unClub;
        this.c2 = unAutreClub;

    }

    public void jeuEssai(){

        c1 = new Club(1, "lolo", "lolo", "lolo", "lolo", "lolo");
        c2 = new Club(2, "lala", "lala", "lala", "lala", "lala");

        Joueur j1 = new Joueur(1, "Toto1", "Toto", "01/01/1992");
        Joueur j2 = new Joueur(2, "Toto2", "Toto", "01/01/1992");
        Joueur j3 = new Joueur(3, "Toto3", "Toto", "01/01/1992");
        Joueur j4 = new Joueur(4, "Tata4", "Tata", "01/01/1992");
        Joueur j5 = new Joueur(5, "Tata5", "Tata", "01/01/1992");

        Joueur j6 = new Joueur(6, "Tutu6", "Tutu", "01/01/1992");
        Joueur j7 = new Joueur(7, "Tutu7", "tutu", "01/01/1992");
        Joueur j8 = new Joueur(8, "Tutu8", "Tutu", "01/01/1992");
        Joueur j9 = new Joueur(9, "Titi9", "Titi", "01/01/1992");
        Joueur j10 = new Joueur(10, "Titi10", "Titi", "01/01/1992");

        c1.ajouterTitulaire1(j1);
        c1.ajouterTitulaire1(j2);
        c1.ajouterTitulaire1(j3);
        c1.ajouterRemplacant1(j4);
        c1.ajouterRemplacant1(j5);

        c2.ajouterTitulaire2(j6);
        c2.ajouterTitulaire2(j7);
        c2.ajouterTitulaire2(j8);
        c2.ajouterRemplacant2(j9);
        c2.ajouterRemplacant2(j10);
        MainActivity.leMatch.setC1(c1);
        MainActivity.leMatch.setC2(c2);
        MainActivity.leMatch.setId(1);
    }


    public void ajouterButA(){
        butA = butA+1;
    }

    public void ajouterButB(){
        butB = butB+1;
    }

    public int getButA() {
        return butA;
    }

    public void setButA(int butA) {
        this.butA = butA;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getButB() {
        return butB;
    }

    public void setButB(int butB) {
        this.butB = butB;
    }

    public Club getC1() {
        return c1;
    }

    public void setC1(Club c1) {
        this.c1 = c1;
    }

    public Club getC2() {
        return c2;
    }

    public void setC2(Club c2) {
        this.c2 = c2;
    }

}
