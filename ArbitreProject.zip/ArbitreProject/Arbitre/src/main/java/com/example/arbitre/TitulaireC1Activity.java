package com.example.arbitre;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.arbitre.classe_metier.Club;

/**
 * Created by Charline on 31/12/13.
 */
public class TitulaireC1Activity extends Activity {


    @Override
    protected void onCreate(Bundle savedInstanceState){

        super.onCreate(savedInstanceState);
        setContentView(R.layout.titulaire_equipe1);

        final  Club c1 = MainActivity.leMatch.getC1();

        //création de l'adapter de l'équipe 1
        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,c1.versTableauC1("titulaires"));

        //Récupération de la liste view
        ListView list1 = (ListView)findViewById(R.id.remplace_titulaire_equip1);

        //On passe nos données au composant ListView
        list1.setAdapter(adapter1);

        list1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getBaseContext(), RemplaceC1Activity.class);
                intent.putExtra("positionTitulaire",position);
                startActivityForResult(intent, 1);
            }
        });
    }

    protected void onActivityResult (int requestCode, int resultCode, Intent data){
        if (requestCode == 1)
        {
            if(resultCode == RESULT_OK){
                TitulaireC1Activity.this.finish();
            }
        }
    }
}
