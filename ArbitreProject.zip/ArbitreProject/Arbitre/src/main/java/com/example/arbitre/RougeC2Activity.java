package com.example.arbitre;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.example.arbitre.classe_metier.Club;
import com.example.arbitre.classe_metier.Joueur;
import com.example.arbitre.classe_metier.Match;

/**
 * Created by Charline on 02/01/14.
 */
public class RougeC2Activity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState){

        super.onCreate(savedInstanceState);
        setContentView(R.layout.rouge_equipe2);

        final Club c2 = MainActivity.leMatch.getC2();

        //création de l'adapter de l'équipe 1
        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,c2.versTableauC2("titulaires"));

        //Récupération de la liste view
        ListView list1 = (ListView)findViewById(R.id.listV_rouge_equipe2);

        //On passe nos données au composant ListView
        list1.setAdapter(adapter1);

        list1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Joueur Exclus = Club.lesTitulaires2.get(position);
                c2.supprimerTitulaire2(Exclus);
                c2.ajouterExclus2(Exclus);

                Toast.makeText(RougeC2Activity.this, "Joueur exclus du match", Toast.LENGTH_SHORT).show();

                Intent returnIntent = new Intent();
                setResult(RESULT_OK,returnIntent);
                RougeC2Activity.this.finish();
            }
        });
    }
}
