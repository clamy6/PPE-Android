package com.example.arbitre;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.example.arbitre.classe_metier.Club;
import com.example.arbitre.classe_metier.Joueur;
import com.example.arbitre.classe_metier.Match;

import java.util.ArrayList;

/**
 * Created by Charline on 04/12/13.
 */
public class EquipeActivity extends Activity{



    @Override
    protected void onCreate(Bundle savedInstanceState){

        super.onCreate(savedInstanceState);
        setContentView(R.layout.equipes);

        Club c1 = MainActivity.leMatch.getC1();
        Club c2 = MainActivity.leMatch.getC2();

        //création de l'adapter de l'équipe 1
        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,c1.versTableauC1("titulaires"));
        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,c1.versTableauC1("remplacants"));
        ArrayAdapter<String> adapter3 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,c2.versTableauC2("titulaires"));
        ArrayAdapter<String> adapter4 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,c2.versTableauC2("remplacants"));

        //Récupération de la liste view
        ListView list1 = (ListView)findViewById(R.id.verif_list_titulaires_equip1);
        ListView list2 = (ListView)findViewById(R.id.verif_list_remplacants_equip1);
        ListView list3 = (ListView)findViewById(R.id.verif_list_titulaires_equip2);
        ListView list4 = (ListView)findViewById(R.id.verif_list_remplacants_equip2);

        //On passe nos données au composant ListView
        list1.setAdapter(adapter1);
        list2.setAdapter(adapter2);
        list3.setAdapter(adapter3);
        list4.setAdapter(adapter4);



        Button button = (Button) findViewById(R.id.bt_ok_liste);
        button.setOnClickListener(new View.OnClickListener() {
@Override
public void onClick(View view) {
        //On affiche dans un Toast le texte contenu dans l'EditText de notre AlertDialog
        Toast.makeText(EquipeActivity.this, "C'est parti...", Toast.LENGTH_SHORT).show();
        //méthode qui démarre une nouvelle Activity
        Intent i = new Intent(EquipeActivity.this, ParametreActivity.class);
        startActivityForResult(i,1);
        }
        });


    }
}
