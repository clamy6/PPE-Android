package com.example.arbitre;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;

import com.example.arbitre.classe_metier.Club;

/**
 * Created by Charline on 02/01/14.
 */
public class PenaliteC1Activity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState){

        super.onCreate(savedInstanceState);
        setContentView(R.layout.penalite_equipe1);

        ImageButton button1 = (ImageButton) findViewById(R.id.bt_rouge_equipe1);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(PenaliteC1Activity.this, RougeC1Activity.class);
                startActivityForResult(i,1);
            }
        });

        ImageButton button2 = (ImageButton) findViewById(R.id.bt_jaune_equipe1);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(PenaliteC1Activity.this, JauneC1Activity.class);
                startActivityForResult(i,2);
            }
        });
    }

    protected void onActivityResult (int requestCode, int resultCode, Intent data){
        if (requestCode == 1)
        {
            if(resultCode == RESULT_OK){
                PenaliteC1Activity.this.finish();
            }
        }
        if (requestCode == 2)
        {
            if(resultCode == RESULT_OK){
                PenaliteC1Activity.this.finish();
            }
        }
    }
}
