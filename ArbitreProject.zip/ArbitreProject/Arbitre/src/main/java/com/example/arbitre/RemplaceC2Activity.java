package com.example.arbitre;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.example.arbitre.classe_metier.Club;
import com.example.arbitre.classe_metier.Joueur;

/**
 * Created by Charline on 02/01/14.
 */
public class RemplaceC2Activity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState){

        super.onCreate(savedInstanceState);
        setContentView(R.layout.remplacant_equipe2);
        final int positionTitulaire = this.getIntent().getIntExtra("positionTitulaire",-1);

        final Club c2 = MainActivity.leMatch.getC2();

        //création de l'adapter de l'équipe 1
        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,c2.versTableauC2("remplacants"));

        //Récupération de la liste view
        ListView list1 = (ListView)findViewById(R.id.remplace_remplacant_equip2);

        //On passe nos données au composant ListView
        list1.setAdapter(adapter1);

        list1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                Joueur leRentrant = Club.lesRemplacants2.get(position);
                Joueur leSortant = Club.lesTitulaires2.get(positionTitulaire);
                c2.ajouterTitulaire2(leRentrant);
                c2.supprimerRemplacant2(leRentrant);

                c2.supprimerTitulaire2(leSortant);
                c2.ajouterRemplacant2(leSortant);

                Toast.makeText(RemplaceC2Activity.this, "Changement enregistré!", Toast.LENGTH_SHORT).show();

                Intent returnIntent = new Intent();
                setResult(RESULT_OK,returnIntent);
                RemplaceC2Activity.this.finish();

            }
        });

    }
}
