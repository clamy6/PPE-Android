package com.example.arbitre;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import com.example.arbitre.classe_metier.Club;
import com.example.arbitre.classe_metier.Match;

/**
 * Created by Charline on 02/01/14.
 */
public class RecapitulatifActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState){

        super.onCreate(savedInstanceState);
        setContentView(R.layout.recapitulatif);

        final Club c1 = MainActivity.leMatch.getC1();
        final Club c2 = MainActivity.leMatch.getC2();

        TextView tv_club1 = (TextView) findViewById(R.id.tv_recap_c1);
        tv_club1.setText(c1.getNom());
        TextView tv_club2 = (TextView) findViewById(R.id.tv_recap_c2);
        tv_club2.setText(c2.getNom());

        TextView tv_butc1 = (TextView) findViewById(R.id.tv_recap_butc1);
        int butc1 = MainActivity.leMatch.getButA();
        tv_butc1.setText(Integer.toString(butc1));

        TextView tv_butc2 = (TextView) findViewById(R.id.tv_recap_butc2);
        int butc2 = MainActivity.leMatch.getButB();
        tv_butc2.setText(Integer.toString(butc2));

        //création de l'adapter de l'équipe 1
        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,c1.versRecap1("jaune"));
        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,c2.versRecap2("jaune"));
        ArrayAdapter<String> adapter3 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,c1.versRecap1("rouge"));
        ArrayAdapter<String> adapter4 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,c2.versRecap2("rouge"));

        //Récupération de la liste view
        ListView list1 = (ListView)findViewById(R.id.listv_recap_jaune_c1);
        ListView list2 = (ListView)findViewById(R.id.listv_recap_jaune_c2);
        ListView list3 = (ListView)findViewById(R.id.listv_recap_rouge_c1);
        ListView list4 = (ListView)findViewById(R.id.listv_recap_rouge_c2);

        //On passe nos données au composant ListView
        list1.setAdapter(adapter1);
        list2.setAdapter(adapter2);
        list3.setAdapter(adapter3);
        list4.setAdapter(adapter4);
    }
}
