package com.example.arbitre.classe_metier;

import android.support.v7.appcompat.R;

import java.util.ArrayList;

/**
 * Created by Charline on 27/11/13.
 */
public class Club {
    private int id;
    private String nom;
    private String mail;
    private String ville;
    private String code;
    private String mdp;

    public static ArrayList<Joueur> lesTitulaires1;
    public static ArrayList<Joueur> lesTitulaires2;
    public static ArrayList<Joueur> lesRemplacants1;
    public static ArrayList<Joueur> lesRemplacants2;
    public static ArrayList<Joueur> lesExclus1;
    public static ArrayList<Joueur> lesExclus2;
    public static ArrayList<Joueur> lesJaunes1;
    public static ArrayList<Joueur> lesJaunes2;
    public static ArrayList<Joueur> lesBut1;
    public static ArrayList<Joueur> lesBut2;


    public Club(int id, String nom, String mail, String ville, String code, String mdp) {
        this.id = id;
        this.nom = nom;
        this.mail = mail;
        this.ville = ville;
        this.code = code;
        this.mdp = mdp;
        lesTitulaires1 = new ArrayList<Joueur>();
        lesTitulaires2 = new ArrayList<Joueur>();
        lesRemplacants1 = new ArrayList<Joueur>();
        lesRemplacants2 = new ArrayList<Joueur>();
        lesExclus1 = new ArrayList<Joueur>();
        lesExclus2 = new ArrayList<Joueur>();
        lesJaunes1 = new ArrayList<Joueur>();
        lesJaunes2 = new ArrayList<Joueur>();
        lesBut1 = new ArrayList<Joueur>();
        lesBut2 = new ArrayList<Joueur>();
    }


    public void ajouterTitulaire1(Joueur j){
        lesTitulaires1.add(j);
    }

    public void ajouterTitulaire2(Joueur j){
        lesTitulaires2.add(j);
    }

    public void ajouterRemplacant1(Joueur j){
        lesRemplacants1.add(j);
    }

    public void ajouterRemplacant2(Joueur j){
        lesRemplacants2.add(j);
    }

    public void supprimerTitulaire1(Joueur j){
        lesTitulaires1.remove(j);
    }

    public void supprimerTitulaire2(Joueur j){
        lesTitulaires2.remove(j);
    }

    public void supprimerRemplacant1(Joueur j){
        lesRemplacants1.remove(j);
    }

    public void supprimerRemplacant2(Joueur j){
        lesRemplacants2.remove(j);
    }

    public void ajouterExclus1(Joueur j){
        lesExclus1.add(j);
    }

    public void ajouterExclus2(Joueur j){
        lesExclus2.add(j);
    }

    public void ajouterJaune1(Joueur j){
        lesJaunes1.add(j);
    }

    public void ajouterJaune2(Joueur j){
        lesJaunes2.add(j);
    }

    public void supprimerJaune1(Joueur j){
        lesJaunes1.remove(j);
    }

    public void supprimerJaune2(Joueur j){
        lesJaunes2.remove(j);
    }

    public void ajouterBut1(Joueur j){
        lesBut1.add(j);
    }

    public void ajouterBut2(Joueur j){
        lesBut2.add(j);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getVille() {
        return ville;
    }

    public void setVille(String ville) {
        this.ville = ville;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMdp() {
        return mdp;
    }

    public void setMdp(String mdp) {
        this.mdp = mdp;
    }

    public static ArrayList<Joueur> getLesTitulaires1() {
        return lesTitulaires1;
    }

    public static void setLesTitulaires1(ArrayList<Joueur> lesTitulaires1) {
        Club.lesTitulaires1 = lesTitulaires1;
    }

    public static ArrayList<Joueur> getLesTitulaires2() {
        return lesTitulaires2;
    }

    public static void setLesTitulaires2(ArrayList<Joueur> lesTitulaires2) {
        Club.lesTitulaires2 = lesTitulaires2;
    }

    public static ArrayList<Joueur> getLesRemplacants1() {
        return lesRemplacants1;
    }

    public static void setLesRemplacants1(ArrayList<Joueur> lesRemplacants1) {
        Club.lesRemplacants1 = lesRemplacants1;
    }

    public static ArrayList<Joueur> getLesRemplacants2() {
        return lesRemplacants2;
    }

    public static void setLesRemplacants2(ArrayList<Joueur> lesRemplacants2) {
        Club.lesRemplacants2 = lesRemplacants2;
    }

    public static ArrayList<Joueur> getLesExclus1() {
        return lesExclus1;
    }

    public static void setLesExclus1(ArrayList<Joueur> lesExclus1) {
        Club.lesExclus1 = lesExclus1;
    }

    public static ArrayList<Joueur> getLesExclus2() {
        return lesExclus2;
    }

    public static void setLesExclus2(ArrayList<Joueur> lesExclus2) {
        Club.lesExclus2 = lesExclus2;
    }

    public static ArrayList<Joueur> getLesJaunes1() {
        return lesJaunes1;
    }

    public static void setLesJaunes1(ArrayList<Joueur> lesJaunes1) {
        Club.lesJaunes1 = lesJaunes1;
    }

    public static ArrayList<Joueur> getLesJaunes2() {
        return lesJaunes2;
    }

    public static void setLesJaunes2(ArrayList<Joueur> lesJaunes2) {
        Club.lesJaunes2 = lesJaunes2;
    }

    public static ArrayList<Joueur> getLesBut1() {
        return lesBut1;
    }

    public static void setLesBut1(ArrayList<Joueur> lesBut1) {
        Club.lesBut1 = lesBut1;
    }

    public static ArrayList<Joueur> getLesBut2() {
        return lesBut2;
    }

    public static void setLesBut2(ArrayList<Joueur> lesBut2) {
        Club.lesBut2 = lesBut2;
    }

    public String[] versTableauC1(String choix){
        ArrayList<Joueur> liste;
        if (choix.equals("titulaires")){
            liste = getLesTitulaires1();
        }else{
            liste = getLesRemplacants1();
        }
        String[] resu = new String[liste.size()];
        int i = 0;
        for(Joueur j : liste){
            resu[i] = j.ligneTableau();
            i++;
        }
        return resu;
    }

    public static String[] versTableauC2(String choix){
        ArrayList<Joueur> liste;
        if (choix.equals("titulaires")){
            liste = getLesTitulaires2();
        }else{
            liste = getLesRemplacants2();
        }
        String[] resu = new String[liste.size()];
        int i = 0;
        for(Joueur j : liste){
            resu[i] = j.ligneTableau();
            i++;
        }
        return resu;
    }

    public static String[] versRecap1(String couleur){
        ArrayList<Joueur> listeC;
        if (couleur.equals("jaune")){
            listeC = getLesJaunes1();
        }else{
            listeC = getLesExclus1();
        }
        String[] resu = new String[listeC.size()];
        int i = 0;
        for(Joueur j : listeC){
            resu[i] = j.ligneTableau();
            i++;
        }
        return resu;
    }

    public static String[] versRecap2(String couleur){
        ArrayList<Joueur> listeC;
        if (couleur.equals("jaune")){
            listeC = getLesJaunes2();
        }else{
            listeC = getLesExclus2();
        }
        String[] resu = new String[listeC.size()];
        int i = 0;
        for(Joueur j : listeC){
            resu[i] = j.ligneTableau();
            i++;
        }
        return resu;
    }
}

