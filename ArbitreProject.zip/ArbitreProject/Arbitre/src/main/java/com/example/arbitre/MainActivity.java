package com.example.arbitre;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.arbitre.classe_metier.Match;

public class MainActivity extends Activity {
public static Match leMatch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.leMatch = new Match();
        this.leMatch.jeuEssai();


        Button button = (Button) findViewById(R.id.bt_commencer);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //On affiche dans un Toast le texte contenu dans l'EditText de notre AlertDialog
                Toast.makeText(MainActivity.this, "C'est parti...", Toast.LENGTH_SHORT).show();
                //méthode qui démarre une nouvelle Activity
                Intent i = new Intent(MainActivity.this, ParametreActivity.class);
                startActivityForResult(i,1);
            }
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId()) {
            case R.id.action_settings:
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
