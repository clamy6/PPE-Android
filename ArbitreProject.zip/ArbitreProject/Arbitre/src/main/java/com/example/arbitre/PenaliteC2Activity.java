package com.example.arbitre;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

/**
 * Created by Charline on 02/01/14.
 */
public class PenaliteC2Activity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState){

        super.onCreate(savedInstanceState);
        setContentView(R.layout.penalite_equipe2);

        ImageButton button1 = (ImageButton) findViewById(R.id.bt_rouge_equipe2);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(PenaliteC2Activity.this, RougeC2Activity.class);
                startActivityForResult(i,1);
            }
        });

        ImageButton button2 = (ImageButton) findViewById(R.id.bt_jaune_equipe2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(PenaliteC2Activity.this, JauneC2Activity.class);
                startActivityForResult(i,2);
            }
        });
    }

    protected void onActivityResult (int requestCode, int resultCode, Intent data){
        if (requestCode == 1)
        {
            if(resultCode == RESULT_OK){
                PenaliteC2Activity.this.finish();
            }
        }
        if (requestCode == 2)
        {
            if(resultCode == RESULT_OK){
                PenaliteC2Activity.this.finish();
            }
        }
    }
}
