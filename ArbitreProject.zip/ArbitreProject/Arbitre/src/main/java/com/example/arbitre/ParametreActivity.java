package com.example.arbitre;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.arbitre.classe_metier.Match;

/**
 * Created by Charline on 27/11/13.
 */
public class ParametreActivity extends Activity{

    @Override
    protected void onCreate(Bundle savedInstanceState){

        super.onCreate(savedInstanceState);
        setContentView(R.layout.parametres);

        final TextView test = (TextView)findViewById(R.id.test1);

        //Bouton qui renvoit vers la liste des équipes qui jouent
        Button button = (Button) findViewById(R.id.bt_verifier_equipe);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //TextView tv_code = (TextView)findViewById(R.id.code);
                //MatchActivity.leMatch = new Match(Integer.parseInt(tv_code.getText().toString()));

                //On affiche dans un Toast le texte contenu dans l'EditText de notre AlertDialog
                Toast.makeText(ParametreActivity.this, "C'est parti...", Toast.LENGTH_SHORT).show();
                //méthode qui démarre une nouvelle Activity
                Intent i = new Intent(ParametreActivity.this, EquipeActivity.class);
                startActivityForResult(i,1);
            }
        });

        //Bouton qui renvoit vers le début du match
        Button button1 = (Button) findViewById(R.id.bt_start_match);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try{
                    int code = MainActivity.leMatch.getId();
                    EditText codeM = (EditText) findViewById(R.id.code);
                    String codeMatch = codeM.getText().toString();
                    int verif = new Integer(codeMatch).intValue();

                    test.setText(Integer.toString(code));

                    if(code == verif){
                        //On affiche dans un Toast le texte contenu dans l'EditText de notre AlertDialog
                        Toast.makeText(ParametreActivity.this, "C'est parti...", Toast.LENGTH_SHORT).show();
                        //méthode qui démarre une nouvelle Activity
                        Intent in = new Intent(ParametreActivity.this, MatchActivity.class);
                        startActivityForResult(in,2);
                    }else{
                        Toast.makeText(ParametreActivity.this, "Le code n'est pas bon", Toast.LENGTH_SHORT).show();
                    }
                }catch (NumberFormatException e){
                    Toast.makeText(ParametreActivity.this, "Le code n'est pas valide", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

}
