package com.example.arbitre;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.example.arbitre.classe_metier.Club;
import com.example.arbitre.classe_metier.Joueur;
import com.example.arbitre.classe_metier.Match;

/**
 * Created by Charline on 02/01/14.
 */
public class RemplaceC1Activity extends Activity {


    @Override
    protected void onCreate(Bundle savedInstanceState){

        super.onCreate(savedInstanceState);
        setContentView(R.layout.remplacant_equipe1);

        final int positionTitulaire = this.getIntent().getIntExtra("positionTitulaire",-1);
        final Club c1 = MainActivity.leMatch.getC1();

        //création de l'adapter de l'équipe 1
        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,c1.versTableauC1("remplacants"));

        //Récupération de la liste view
        ListView list1 = (ListView)findViewById(R.id.remplace_remplacant_equip1);

        //On passe nos données au composant ListView
        list1.setAdapter(adapter1);

        list1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                Joueur leRentrant = Club.lesRemplacants1.get(position);
                Joueur leSortant = Club.lesTitulaires1.get(positionTitulaire);
                c1.ajouterTitulaire1(leRentrant);
                c1.supprimerRemplacant1(leRentrant);

                c1.supprimerTitulaire1(leSortant);
                c1.ajouterRemplacant1(leSortant);

                Toast.makeText(RemplaceC1Activity.this, "Changement enregistré!", Toast.LENGTH_SHORT).show();

                Intent returnIntent = new Intent();
                setResult(RESULT_OK,returnIntent);
                RemplaceC1Activity.this.finish();

            }
        });
    }
}
