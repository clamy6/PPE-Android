package com.example.arbitre;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.TextView;
import android.widget.Toast;

import com.example.arbitre.classe_metier.Club;
import com.example.arbitre.classe_metier.Match;

/**
 * Created by Charline on 04/12/13.
 */
public class MatchActivity extends Activity implements Chronometer.OnChronometerTickListener{



    @Override
    protected void onCreate(Bundle savedInstanceState){

        super.onCreate(savedInstanceState);
        setContentView(R.layout.match);

        final Club c1 = MainActivity.leMatch.getC1();
        final Club c2 = MainActivity.leMatch.getC2();

        TextView tv_club1 = (TextView) findViewById(R.id.nom_c1);
        tv_club1.setText(c1.getNom());

        TextView tv_club2 = (TextView) findViewById(R.id.nom_c2);
        tv_club2.setText(c2.getNom());

        //Bouton ajouter but equipe 1
        Button button0 = (Button) findViewById(R.id.bt_butA);
        button0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MatchActivity.this, ButC1Activity.class);
                startActivityForResult(i,1);
                MainActivity.leMatch.ajouterButA();
                TextView tv_butA = (TextView) findViewById(R.id.tv_butA);
                int butA = MainActivity.leMatch.getButA();
                tv_butA.setText(Integer.toString(butA));
            }
        });

        //Bouton ajouter but equipe 2
        Button button1 = (Button) findViewById(R.id.bt_butB);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MatchActivity.this, ButC2Activity.class);
                startActivityForResult(i,2);
                MainActivity.leMatch.ajouterButB();
                TextView tv_butB = (TextView) findViewById(R.id.tv_butB);
                int butB = MainActivity.leMatch.getButB();
                tv_butB.setText(Integer.toString(butB));
            }
        });

        //Bouton vers la page des remplacements equipe 1
        Button button2 = (Button) findViewById(R.id.bt_remp_equip1);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MatchActivity.this, TitulaireC1Activity.class);
                startActivityForResult(i,3);
            }
        });

        //Bouton vers la page des remplacements equipe 2
        Button button3 = (Button) findViewById(R.id.bt_remp_equip2);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MatchActivity.this, TitulaireC2Activity.class);
                startActivityForResult(i,4);
            }
        });

        //Bouton vers la page des penalités equipe 1
        Button button4 = (Button) findViewById(R.id.bt_penalites_equipe1);
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //méthode qui démarre une nouvelle Activity
                Intent i = new Intent(MatchActivity.this, PenaliteC1Activity.class);
                startActivityForResult(i,5);
            }
        });

        //Bouton vers la page des penalités equipe 2
        Button button5 = (Button) findViewById(R.id.bt_penalites_equipe2);
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //méthode qui démarre une nouvelle Activity
                Intent i = new Intent(MatchActivity.this, PenaliteC2Activity.class);
                startActivityForResult(i,6);
            }
        });


        Button button8 = (Button) findViewById(R.id.bt_recap);
        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //méthode qui démarre une nouvelle Activity
                Intent i = new Intent(MatchActivity.this, RecapitulatifActivity.class);
                startActivityForResult(i,7);
            }
        });
        button8.setVisibility(View.INVISIBLE);

        //Bouton du chronomètre
        Button button6 = (Button) findViewById(R.id.bt_start_chrono);
        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MatchActivity.this, "Début de la partie", Toast.LENGTH_SHORT).show();
                MatchActivity.this.startChronometer(null);
            }
        });

        Button button7 = (Button) findViewById(R.id.bt_reprendre_chrono);
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MatchActivity.this, "Début seconde mi-temps", Toast.LENGTH_SHORT).show();
                MatchActivity.this.startChronometer2(null);
            }
        });
    }

    public void startChronometer(View view){
        Chronometer chrono = ((Chronometer) findViewById(R.id.chronometer));
        chrono.setBase(SystemClock.elapsedRealtime());
        chrono.setOnChronometerTickListener(this);
        ((Chronometer) findViewById(R.id.chronometer)).start();
    }

    public void startChronometer2(View view){
        Chronometer chrono = ((Chronometer) findViewById(R.id.chronometer));
        //chrono.setFormat("MM:SS");
        chrono.setBase(SystemClock.elapsedRealtime()-(2700*1000));
        chrono.setOnChronometerTickListener(this);
        //chrono.setOnChronometerTickListener(this);
        ((Chronometer) findViewById(R.id.chronometer)).start();
    }

    public void stopChronometer(View view){
        ((Chronometer) findViewById(R.id.chronometer)).stop();
    }

    @Override
    public void onChronometerTick(Chronometer chronometer){
        long t = SystemClock.elapsedRealtime() - chronometer.getBase();
        int h = (int)(t/3600000);
        int m = (int)(t - h*3600000)/60000;
        int s = (int)(t - h*3600000 - m*60000)/1000;

        m = m + (h*60);
        String hh = h < 10 ? "0"+h: h+"";
        String mm = m < 10 ? "0"+m: m+"";
        String ss = s < 10 ? "0"+s: s+"";
        chronometer.setText(mm +":"+ss);

        if("45:00".equals(chronometer.getText())){

            chronometer.stop();
        }

        if("90:00".equals(chronometer.getText())){
            chronometer.setTextColor(Color.RED);
            chronometer.stop();
            Button button0 = (Button) findViewById(R.id.bt_butA);
            button0.setVisibility(View.INVISIBLE);

            Button button1 = (Button) findViewById(R.id.bt_butB);
            button1.setVisibility(View.INVISIBLE);

            Button button2 = (Button) findViewById(R.id.bt_remp_equip1);
            button2.setVisibility(View.INVISIBLE);

            Button button3 = (Button) findViewById(R.id.bt_remp_equip2);
            button3.setVisibility(View.INVISIBLE);

            Button button4 = (Button) findViewById(R.id.bt_penalites_equipe1);
            button4.setVisibility(View.INVISIBLE);

            Button button5 = (Button) findViewById(R.id.bt_penalites_equipe2);
            button5.setVisibility(View.INVISIBLE);

            Button button6 = (Button) findViewById(R.id.bt_start_chrono);
            button6.setVisibility(View.INVISIBLE);

            Button button7 = (Button) findViewById(R.id.bt_reprendre_chrono);
            button7.setVisibility(View.INVISIBLE);

            Button button8 = (Button) findViewById(R.id.bt_recap);
            button8.setVisibility(0);
        }
    }
}
